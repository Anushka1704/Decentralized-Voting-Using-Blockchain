from django.apps import AppConfig


class BallotConfig(AppConfig):
    name = 'ballot'
